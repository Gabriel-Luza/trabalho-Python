num = int(input('Informe um número: '))

resultado = (num%2)

if resultado != 0:
    print('Seu número é IMPAR!')
else:
    print('Seu número é PAR!')