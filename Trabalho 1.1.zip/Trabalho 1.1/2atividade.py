num = float(input('Digite um número qualquer: '))

if int(num // 1 == num):
    print('Seu número é INTEIRO!')
else:
    print('Seu número é DECIMAL!')