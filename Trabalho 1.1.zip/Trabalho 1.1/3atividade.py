print('* OPERAÇÕES *')
print(' ')

num1 = int(input('Digite um número qualquer: '))
num2 = int(input('Digite outro número qualquer: '))

operacao = int(input('Qual operação deseja realizar?'
                 '\n(1) Adição'
                 '\n(2) Subtração'
                 '\n(3) Divisão'
                 '\n(4) Multiplicação'
                 '\nOperação: '))

if operacao == 1:
    operacao = (num1) + (num2)
elif operacao == 2:
    operacao = (num1) - (num2)
elif operacao == 3:
    operacao = (num1) / (num2)
elif operacao == 4:
    operacao = (num1) * (num2)
else:
    print('Opção Inválida!!!')
    exit()

print('Resultado: ', operacao)


if operacao != 0:
    print('Seu número é impar!')
else:
    print('Seu número é par!')

if operacao >= 0:
    print('Número positivo!')
else:
    print('Número negativo!')

if int(operacao // 1 == operacao):
    print('Seu número é inteiro!')
else:
    print('Seu número é decimal!')



