print('* QUESTIONÁRIO *')
print(' ')

perguntas = []

perguntas.append(input('Telefonou para a vítima? 1/Sim | 0/Não: '))
perguntas.append(input('Esteve no local do crime? 1/Sim | 0/Não: '))
perguntas.append(input('Mora perto da vítima? 1/Sim | 0/Não: '))
perguntas.append(input('Devia para a vítima? 1/Sim | 0/Não: '))
perguntas.append(input('Já trabalhou com a vítima? 1/Sim | 0/Não: '))

soma_respostas = 0
for i in perguntas:
    soma_respostas += int(i)

if (soma_respostas < 2):
 print("A pessoa é: Inocente")

elif (soma_respostas == 2):
 print("A pessoa é: Suspeita")

elif (3 <= soma_respostas <= 4):
 print("A pessoa é: Cúmplice")

elif (soma_respostas == 5):
 print("A pessoa é: Assassino")
