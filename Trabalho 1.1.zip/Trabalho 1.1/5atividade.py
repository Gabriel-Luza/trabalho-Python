combustivel = str(input('Informe o tipo de combustível que você colocou: '))
litro = float(input ('Quantos litros você colocou?: '))

if combustivel == "A":
    alcool = 1.90
    custo = litro * alcool

    if litro <= 20:
        des1 = (custo * 3)/100
        print("O desconto de combustível foi de : {} e o preço agora é {}".format(des1, custo-des1))

    elif litro > 20:
            desc2 = (custo * 5)/100
            print("O desconto de combustível foi de : {} e o preço agora é {}".format(desc2, custo-desc2))

elif combustivel == "G":
    gasolina = 2.50
    custo = litro * gasolina

    if litro <= 20:
            desc3 = (custo * 4)/100
            print("O desconto de combustível foi de : {} e o preço agora é {}".format(desc3, custo-desc3))

    elif litro > 20:
            desc4 = (custo * 6)/100
            print("O desconto de combustível foi de : {} e o preço agora é {}".format(desc4, custo-desc4))